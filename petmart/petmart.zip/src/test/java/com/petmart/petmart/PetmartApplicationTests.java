package com.petmart.petmart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetmartApplicationTests {

	@Test
	void contextLoads() {
	}

}
